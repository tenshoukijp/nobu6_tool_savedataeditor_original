//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SaveDataEditor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_NB6SLOT                     203
#define IDD_ATTACHDLG                   206
#define IDC_SLOT1                       1005
#define IDC_SLOT2                       1006
#define IDC_SLOT3                       1007
#define IDC_SLOT4                       1008
#define IDC_SLOT5                       1009
#define IDC_SLOT6                       1010
#define IDC_SLOT7                       1011
#define IDC_SLOT8                       1012
#define IDC_COMBO2                      1015
#define IDC_LIST1                       1016
#define ID_MAX_GRAIN                    32774
#define ID_MAX_TOWN                     32776
#define ID_MAX_BUILD                    32778
#define ID_MAX_LOYAL                    32779
#define ID_MAX_EXP                      32781
#define ID_CALC_EXP                     32782
#define ID_CALC_EXP2                    32786
#define ID_SELECTALL                    32788
#define ID_YOUNG                        32790
#define ID_TABCHANGE                    32794
#define ID_CHANGEATTACH                 32797
#define ID_SOLDIER                      32799
#define ID_SENIORITY                    32801
#define ID_DUMP                         32802
#define ID_TEST                         32804

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        207
#define _APS_NEXT_COMMAND_VALUE         32806
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
